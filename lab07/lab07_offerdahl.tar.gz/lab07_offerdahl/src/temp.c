int int_glob;
double d_glob;

main() 
{
  int loc1, loc2;
  double d_arr[10], d_loc; 
  d_arr[0] = 3;

  loc1 = 0;
  if(loc1 == 10){
    int b_loc1;
    double bd_loc2;
  }
}
