int a, y;

test(int x, float z)
{
  int x, y;
  if (x && y){
    int s, p, x;
    s = p = x = 0;
  }
  {
    float t, u, s;
  }
  return 1;
}
