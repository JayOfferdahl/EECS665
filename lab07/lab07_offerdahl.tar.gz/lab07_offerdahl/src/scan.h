void initlex();
void initrw(int, char *);
int yylex();
void skip();
void comment();
int istype(int);
void putbak(int);
int quote(char []);
