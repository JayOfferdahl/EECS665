Hey Tyler,

The makefile that I've included to run this program
can be used by typing 'make test', which uses
std::in to send information from 'input.txt' to my
program. If you're trying to use a file that's not
named 'input.txt', please run the following command:

./nfa2dfa < [NAME OF INPUT]

Thanks for reading, 

Jay